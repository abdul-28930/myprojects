# Responsive Plants Website 🎍

### Responsive Plants Website 🎍

- Responsive Plants Website Using HTML, CSS and JavaScript.
- Contains animations when scrolling.
- Includes a dark and light mode.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.
