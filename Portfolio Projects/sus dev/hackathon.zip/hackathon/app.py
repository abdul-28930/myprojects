from flask import Flask,render_template,request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/model')
def model():
    return render_template('upload.html')



@app.route('/upload', methods=['POST'])
def upload_file():
    if 'upload_file' in request.files:
        file = request.files['upload_file']
        print(file)
        if file.filename != '':
            # Access the file data without saving
            file_data = file.read()
            # Process the file data as needed
            # For example, you can perform image processing, analysis, etc.
            return 'File uploaded successfully!'
    return 'No file uploaded.'




if __name__ == '__main__':
    app.run(debug=True)
